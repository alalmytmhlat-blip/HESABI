import 'package:flutter/material.dart';

void main() => runApp(const MohasebSoftApp());

const Color brandBlue = Color(0xFF0878AE);
const Color darkBlue = Color(0xFF075E91);
const Color lightBlue = Color(0xFFEAF5FA);

class MohasebSoftApp extends StatelessWidget {
  const MohasebSoftApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'محاسب سوفت',
      theme: ThemeData(
        useMaterial3: false,
        fontFamily: 'Arial',
        primaryColor: brandBlue,
        scaffoldBackgroundColor: Colors.white,
        appBarTheme: const AppBarTheme(
          backgroundColor: brandBlue,
          foregroundColor: Colors.white,
          elevation: 0,
          centerTitle: false,
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

class AppBarTitle extends StatelessWidget {
  final String title;
  final bool back;
  const AppBarTitle({super.key, required this.title, this.back = false});

  @override
  Widget build(BuildContext context) {
    return AppBar(
      automaticallyImplyLeading: false,
      titleSpacing: 8,
      leading: back
          ? IconButton(
              icon: const Icon(Icons.arrow_back, size: 21),
              onPressed: () => Navigator.maybePop(context),
            )
          : null,
      title: Row(
        children: [
          if (!back)
            const Icon(Icons.menu, size: 20),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              title,
              textAlign: TextAlign.right,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
      actions: [
        IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
        IconButton(onPressed: () {}, icon: const Icon(Icons.share)),
      ],
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final Map<String, bool> expanded = {
    'عمليات مخزنية': false,
    'قيود ومسحوبات': false,
    'أصناف': false,
    'العملاء': false,
    'التقارير': true,
  };

  final Map<String, List<String>> menus = {
    'عمليات مخزنية': ['حركة الأصناف', 'جرد المخزون', 'توريد مخزني'],
    'قيود ومسحوبات': ['قيد يومي', 'سند صرف', 'سند قبض'],
    'أصناف': ['الأصناف', 'المجموعات', 'الوحدات'],
    'العملاء': ['بيانات العملاء', 'حركة الحسابات', 'كشف حساب'],
    'التقارير': ['حركة الأصناف', 'تقرير الأرباح', 'تقارير المبيعات'],
  };

  void open(String label) {
    if (label.contains('حركة الأصناف')) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => const ProductMovementScreen()));
    } else if (label.contains('حركة الحسابات') || label.contains('كشف حساب')) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => const AccountMovementScreen()));
    } else if (label.contains('بيانات')) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => const AccountsScreen()));
    } else {
      Navigator.push(context, MaterialPageRoute(builder: (_) => GenericListScreen(title: label)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: const AppBarTitle(title: 'محاسب سوفت'),
        drawer: const AppDrawer(),
        body: Column(
          children: [
            const SizedBox(height: 8),
            const QuickActions(),
            const SizedBox(height: 10),
            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  ...menus.entries.map((entry) => _section(entry.key, entry.value)),
                  const SizedBox(height: 30),
                ],
              ),
            ),
            const BottomBrandBar(),
          ],
        ),
      ),
    );
  }

  Widget _section(String title, List<String> children) {
    final isOpen = expanded[title] ?? false;
    return Column(
      children: [
        InkWell(
          onTap: () => setState(() => expanded[title] = !isOpen),
          child: Container(
            height: 38,
            margin: const EdgeInsets.only(bottom: 1),
            padding: const EdgeInsets.symmetric(horizontal: 10),
            color: brandBlue,
            child: Row(
              children: [
                Icon(isOpen ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down,
                    color: Colors.white, size: 20),
                const Spacer(),
                Text(title, style: const TextStyle(color: Colors.white, fontSize: 13)),
              ],
            ),
          ),
        ),
        if (isOpen)
          ...children.map(
            (item) => InkWell(
              onTap: () => open(item),
              child: Container(
                height: 32,
                padding: const EdgeInsets.symmetric(horizontal: 15),
                decoration: const BoxDecoration(
                  border: Border(bottom: BorderSide(color: Color(0xFFE8E8E8))),
                ),
                child: Align(
                  alignment: Alignment.centerRight,
                  child: Text(item, style: const TextStyle(fontSize: 12, color: Colors.black87)),
                ),
              ),
            ),
          ),
      ],
    );
  }
}

class QuickActions extends StatelessWidget {
  const QuickActions({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 110,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _action(context, 'المبيعات', Icons.shopping_cart, () => _go(context, const GenericListScreen(title: 'المبيعات'))),
          _action(context, 'المشتريات', Icons.shopping_bag, () => _go(context, const GenericListScreen(title: 'المشتريات'))),
          _action(context, 'قبض/صرف', Icons.payments, () => _go(context, const GenericListScreen(title: 'قبض / صرف'))),
          _action(context, 'الحسابات', Icons.account_balance_wallet, () => _go(context, const AccountMovementScreen())),
        ],
      ),
    );
  }

  void _go(BuildContext context, Widget page) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  Widget _action(BuildContext context, String label, IconData icon, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Stack(
            clipBehavior: Clip.none,
            children: [
              Container(
                width: 75,
                height: 58,
                decoration: BoxDecoration(
                  color: brandBlue,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(icon, color: Colors.white, size: 26),
                    const SizedBox(height: 2),
                    Text(label, style: const TextStyle(color: Colors.white, fontSize: 12)),
                  ],
                ),
              ),
              Positioned(
                left: -5,
                top: -5,
                child: Container(
                  width: 21,
                  height: 21,
                  decoration: const BoxDecoration(shape: BoxShape.circle, color: darkBlue),
                  child: const Icon(Icons.add, color: Colors.white, size: 16),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class BottomBrandBar extends StatelessWidget {
  const BottomBrandBar({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 42,
      color: darkBlue,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: const [
          Icon(Icons.account_balance, color: Colors.white, size: 23),
          Text('المكان الرئيسي', style: TextStyle(color: Colors.white, fontSize: 12)),
          Icon(Icons.sync, color: Colors.white, size: 23),
        ],
      ),
    );
  }
}

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    final items = [
      ('الرئيسية', Icons.home),
      ('الإعدادات', Icons.settings),
      ('العملاء', Icons.people),
      ('الأصناف', Icons.inventory_2),
      ('المبيعات', Icons.shopping_cart),
      ('المشتريات', Icons.shopping_bag),
      ('التقارير', Icons.assessment),
      ('حول البرنامج', Icons.info_outline),
      ('خروج', Icons.exit_to_app),
    ];

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Drawer(
        child: Column(
          children: [
            Container(
              height: 100,
              width: double.infinity,
              color: brandBlue,
              alignment: Alignment.center,
              child: const Text(
                'محاسب سوفت',
                style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.bold),
              ),
            ),
            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: items.map((e) => ListTile(
                  dense: true,
                  leading: Icon(e.$2, color: brandBlue, size: 21),
                  title: Text(e.$1, style: const TextStyle(fontSize: 14)),
                  onTap: () {
                    Navigator.pop(context);
                    if (e.$1 == 'الإعدادات') {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen()));
                    } else if (e.$1 == 'العملاء') {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const AccountsScreen()));
                    } else if (e.$1 == 'التقارير') {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const ReportsScreen()));
                    }
                  },
                )).toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  final List<String> settings = const [
    'البيانات الشخصية',
    'خيارات الطباعة',
    'خيارات الألوان',
    'المستخدمين والصلاحيات',
    'التصنيفات',
    'مجموعة الهدف',
    'وحدات القياس',
    'خيارات المخازن',
    'خيارات المبيعات',
    'الواجهة العربية',
    'الضريبة',
    'طباعة باركود الأصناف',
    'خيارات الإشعارات',
    'خيارات أخرى',
  ];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: const AppBarTitle(title: 'الإعدادات', back: true),
        body: ListView.separated(
          itemCount: settings.length,
          separatorBuilder: (_, __) => const Divider(height: 1),
          itemBuilder: (_, i) => ListTile(
            dense: true,
            contentPadding: const EdgeInsets.symmetric(horizontal: 12),
            leading: const Icon(Icons.settings, color: brandBlue, size: 21),
            title: Text(settings[i], style: const TextStyle(fontSize: 13)),
            trailing: const Icon(Icons.chevron_left, size: 19),
            onTap: () {},
          ),
        ),
      ),
    );
  }
}

class AccountMovementScreen extends StatelessWidget {
  const AccountMovementScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final rows = [
      ['أصول', '1752', 'رئيسي'],
      ['التزامات وحقوق الملكية', '96', 'رئيسي'],
      ['مصروفات', '36', 'رئيسي'],
      ['إيرادات', '9', 'رئيسي'],
    ];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: const AppBarTitle(title: 'الحسابات', back: true),
        body: Column(
          children: [
            Container(
              color: brandBlue,
              height: 36,
              child: const Row(
                children: [
                  Expanded(child: Center(child: Text('نوع الحساب', style: TextStyle(color: Colors.white, fontSize: 12)))),
                  Expanded(child: Center(child: Text('عدد الحسابات', style: TextStyle(color: Colors.white, fontSize: 12)))),
                  Expanded(child: Center(child: Text('نوع الحساب', style: TextStyle(color: Colors.white, fontSize: 12)))),
                ],
              ),
            ),
            ...rows.map((r) => Container(
              height: 39,
              decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: Color(0xFFE7E7E7)))),
              child: Row(
                children: [
                  Expanded(child: Center(child: Text(r[0], style: const TextStyle(fontSize: 12)))),
                  Expanded(child: Center(child: Text(r[1], style: const TextStyle(fontSize: 12)))),
                  Expanded(child: Center(child: Text(r[2], style: const TextStyle(fontSize: 12)))),
                ],
              ),
            )),
            const Spacer(),
            Container(height: 35, color: brandBlue, child: const Center(child: Icon(Icons.add_circle_outline, color: Colors.white))),
          ],
        ),
      ),
    );
  }
}

class AccountsScreen extends StatelessWidget {
  const AccountsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final names = ['عميل 1', 'عميل 2', 'عميل 3', 'عميل 4', 'عميل 5', 'عميل 6'];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: const AppBarTitle(title: 'العملاء', back: true),
        body: Column(
          children: [
            Container(
              color: brandBlue,
              height: 38,
              child: const Row(
                children: [
                  Expanded(child: Center(child: Text('اسم العميل', style: TextStyle(color: Colors.white, fontSize: 12)))),
                  Expanded(child: Center(child: Text('مدين', style: TextStyle(color: Colors.white, fontSize: 12)))),
                  Expanded(child: Center(child: Text('دائن', style: TextStyle(color: Colors.white, fontSize: 12)))),
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: names.length,
                itemBuilder: (_, i) => Container(
                  height: 43,
                  decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: Color(0xFFE7E7E7)))),
                  child: Row(
                    children: [
                      Expanded(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 8), child: Text(names[i], style: const TextStyle(fontSize: 12)))),
                      const Expanded(child: Center(child: Text('0', style: TextStyle(fontSize: 12)))),
                      const Expanded(child: Center(child: Text('0', style: TextStyle(fontSize: 12)))),
                    ],
                  ),
                ),
              ),
            ),
            Container(height: 38, color: brandBlue, child: const Center(child: Icon(Icons.add_circle_outline, color: Colors.white))),
          ],
        ),
      ),
    );
  }
}

class ProductMovementScreen extends StatelessWidget {
  const ProductMovementScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final products = [
      ['ركب أمريكي سن 1/2', '294', '188', '106'],
      ['ماسورة خضراء 2×6م', '160', '112', '48'],
      ['ماسورة خضراء 1×6م', '33.575', '13.3', '20.275'],
      ['ركب أمريكي نحاس 3/4', '72', '34', '38'],
      ['ساكت أمريكي 1/2', '100', '70', '30'],
      ['ساكت أمريكي 3/4', '161', '12', '149'],
      ['محبس بلاستيك', '2.928', '2.126', '0.802'],
    ];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: const AppBarTitle(title: 'حركة الأصناف', back: true),
        body: Column(
          children: [
            Container(
              color: brandBlue,
              height: 38,
              child: const Row(
                children: [
                  Expanded(flex: 3, child: Center(child: Text('الصنف', style: TextStyle(color: Colors.white, fontSize: 12)))),
                  Expanded(child: Center(child: Text('الوارد', style: TextStyle(color: Colors.white, fontSize: 12)))),
                  Expanded(child: Center(child: Text('المصرف', style: TextStyle(color: Colors.white, fontSize: 12)))),
                  Expanded(child: Center(child: Text('المتبقي', style: TextStyle(color: Colors.white, fontSize: 12)))),
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: products.length,
                itemBuilder: (_, i) => Container(
                  height: 45,
                  decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: Color(0xFFE5E5E5)))),
                  child: Row(
                    children: [
                      Expanded(flex: 3, child: Padding(padding: const EdgeInsets.symmetric(horizontal: 7), child: Text(products[i][0], style: const TextStyle(fontSize: 11)))),
                      Expanded(child: Center(child: Text(products[i][1], style: const TextStyle(fontSize: 11)))),
                      Expanded(child: Center(child: Text(products[i][2], style: const TextStyle(fontSize: 11)))),
                      Expanded(child: Center(child: Text(products[i][3], style: const TextStyle(fontSize: 11)))),
                    ],
                  ),
                ),
              ),
            ),
            Container(height: 38, color: brandBlue, child: const Center(child: Icon(Icons.add_circle_outline, color: Colors.white))),
          ],
        ),
      ),
    );
  }
}

class ReportsScreen extends StatelessWidget {
  const ReportsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const reports = [
      'المخزون المتبقي',
      'أرصدة العملاء',
      'أرباح الأصناف',
      'العمليات اليومية',
      'القيود اليومية',
      'المخزون',
      'حركة الحسابات',
      'حركة العملاء',
      'فواتير المبيعات',
      'رأس المال العامل',
      'المبيعات حسب العميل',
      'المشتريات حسب المورد',
      'تفاصيل حركة الأصناف',
    ];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: const AppBarTitle(title: 'تقارير أخرى', back: true),
        body: ListView.separated(
          itemCount: reports.length,
          separatorBuilder: (_, __) => const Divider(height: 1),
          itemBuilder: (_, i) => ListTile(
            dense: true,
            title: Text(reports[i], style: const TextStyle(fontSize: 13)),
            trailing: const Icon(Icons.assessment_outlined, color: brandBlue, size: 20),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => GenericListScreen(title: reports[i])),
            ),
          ),
        ),
      ),
    );
  }
}

class GenericListScreen extends StatelessWidget {
  final String title;
  const GenericListScreen({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: brandBlue,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => Navigator.pop(context),
          ),
          title: Text(title, style: const TextStyle(fontSize: 16)),
        ),
        body: ListView.builder(
          itemCount: 12,
          itemBuilder: (_, i) => ListTile(
            dense: true,
            leading: CircleAvatar(
              radius: 14,
              backgroundColor: lightBlue,
              child: Text('${i + 1}', style: const TextStyle(color: brandBlue, fontSize: 11)),
            ),
            title: Text('$title ${i + 1}', style: const TextStyle(fontSize: 13)),
            trailing: const Icon(Icons.chevron_left, color: brandBlue),
            onTap: () {},
          ),
        ),
      ),
    );
  }
}
